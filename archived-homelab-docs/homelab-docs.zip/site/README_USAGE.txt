HOMELAB DOKUMENTATION - LOKALE NUTZUNG
=====================================

OPTION 1 - Direktes Öffnen:
  → Doppelklick auf "index.html"
  → Funktioniert in jedem Browser

OPTION 2 - HTTP-Server (Empfohlen für beste Darstellung):
  
  Windows:
    1. PowerShell im Ordner öffnen
    2. python -m http.server 8080
    3. Browser: http://localhost:8080
  
  macOS/Linux:
    1. Terminal im Ordner öffnen  
    2. python3 -m http.server 8080
    3. Browser: http://localhost:8080

HINWEISE:
  - Suche funktioniert nur mit HTTP-Server
  - Mermaid-Diagramme benötigen HTTP-Server
  - Mobile Ansicht wird korrekt dargestellt
